import numpy as np
from scipy.signal import butter, filtfilt

class SignalIntegrityError(ValueError):
    """Raised when channel signal data integrity check fails (e.g. NaN, Inf, dimension mismatch)."""
    pass

def sae_j211_filter(time_s: np.ndarray, signal_data: np.ndarray, cfc: int) -> np.ndarray:
    """Applies SAE J211 4-pole phaseless Butterworth filter for given Channel Frequency Class (CFC)."""
    if len(signal_data) < 10:
        return signal_data
    
    dt = np.mean(np.diff(time_s))
    sample_rate = 1.0 / dt
    cutoff_hz = cfc * 2.0775
    
    nyquist = 0.5 * sample_rate
    if cutoff_hz >= nyquist:
        cutoff_hz = 0.45 * nyquist
        
    b, a = butter(2, cutoff_hz / nyquist, btype='lowpass')
    filtered = filtfilt(b, a, signal_data)
    return filtered

def process_signal(
    raw_time_s: list[float] | np.ndarray,
    raw_data: list[float] | np.ndarray,
    channel_name: str,
    processing_def: dict,
    input_unit: str = "SI"
) -> tuple[np.ndarray, np.ndarray]:
    """Applies the mandatory 8-step Scientific Processing Pipeline (Contract 1).
    
    Single Source of Truth: Uses parameters from processing_def (ProcessingDefinition model) directly.
    """
    t = np.array(raw_time_s, dtype=np.float64)
    y = np.array(raw_data, dtype=np.float64)

    # 1. Integrity check
    if len(t) == 0 or len(t) != len(y):
        raise SignalIntegrityError("Signal dimension mismatch: time and data length differ.")
    
    # Strict NaN / Inf check (P1 item 13: NO silent nan_to_num fallback)
    if np.any(np.isnan(y)) or np.any(np.isinf(y)):
        raise SignalIntegrityError(f"Channel '{channel_name}' integrity check failed: NaN or Inf values detected in raw data.")

    # 2. Unit Normalization
    if input_unit == "g":
        y = y * 9.80665
    elif input_unit == "lb":
        y = y * 4.44822
    elif input_unit == "ms":
        t = t / 1000.0

    # 3. Channel Validation & Parameter Extraction from ProcessingDefinition
    steps_list = processing_def.get("steps", []) if processing_def else []
    steps_map = {step.get("step"): step.get("params", {}) for step in steps_list if isinstance(step, dict)}

    # Extract CFC from processing_def or channel-specific definition
    filter_params = steps_map.get("filter", {})
    cfc = filter_params.get("channel_frequency_class")
    if not cfc:
        # Standard channel CFC mapping per SAE J211
        if "head" in channel_name.lower(): cfc = 1000
        elif "sled" in channel_name.lower(): cfc = 60
        else: cfc = 600

    # 4. Filter (SAE J211)
    y_filtered = sae_j211_filter(t, y, cfc)

    # 5. Time-Zero Detection (from ProcessingDefinition parameters)
    t0_params = steps_map.get("time_zero", {})
    threshold_g = t0_params.get("threshold_g", 0.5)
    threshold_val = threshold_g * 9.80665 if ("accel" in channel_name.lower() or "sled" in channel_name.lower()) else threshold_g
    
    cross_idx = np.where(np.abs(y_filtered) >= threshold_val)[0]
    t0 = t[cross_idx[0]] if len(cross_idx) > 0 else t[0]
    t_aligned = t - t0

    # 6. Window Selection & 7. Common Analysis Grid (from ProcessingDefinition)
    win_params = steps_map.get("window", {})
    resample_params = steps_map.get("resample", {})
    
    t_start = (win_params.get("start_offset_ms", -10.0)) / 1000.0
    t_end = (win_params.get("end_offset_ms", 180.0)) / 1000.0
    sample_rate_hz = resample_params.get("target_rate_hz", 10000)
    
    num_samples = int(round((t_end - t_start) * sample_rate_hz)) + 1
    grid_t = np.linspace(t_start, t_end, num_samples, dtype=np.float64)

    # 8. Resampling / Interpolation
    grid_y = np.interp(grid_t, t_aligned, y_filtered)

    return grid_t, grid_y
