from sqlalchemy import event
from sqlalchemy.orm import Session
from app.db.models import (
    ModelRevision, MaterialDataset, DummyConfiguration,
    PulseDefinition, RegulatoryStandard, Requirement, EvidenceArtifact
)

IMMUTABLE_MODELS = [
    ModelRevision, MaterialDataset, DummyConfiguration,
    PulseDefinition, RegulatoryStandard, Requirement, EvidenceArtifact
]

class ImmutableRecordError(Exception):
    pass

def setup_immutability_triggers(engine):
    """Sets up event listeners to enforce immutability on SQLAlchemy models for SQLite/Generic engines."""
    
    for model in IMMUTABLE_MODELS:
        @event.listens_for(model, 'before_update')
        def receive_before_update(mapper, connection, target):
            raise ImmutableRecordError(
                f"Immutable record constraint violated: UPDATE is not permitted on {target.__tablename__} (id={target.id})."
            )

        @event.listens_for(model, 'before_delete')
        def receive_before_delete(mapper, connection, target):
            raise ImmutableRecordError(
                f"Immutable record constraint violated: DELETE is not permitted on {target.__tablename__} (id={target.id})."
            )
